﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Text.RegularExpressions;
using EMS.Exception;
using EMS.Entity;


namespace EMS.BL
{
    public class OperationValidations
    {
        //Method to validate Employee data 
        public static bool ValidateEmployee(Employee empObj)
        {
            bool empValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if(empObj.FirstName == string.Empty)
                {
                    empValidated = false;
                    message.Append("Employee First Name should be Provided\n");
                }
                else if (!Regex.IsMatch(empObj.FirstName, "[A-Z][a-z]+"))
                {
                    message.Append("Employee First Name should have alphabets only and it should start with capital\n");
                    empValidated = false;
                }
                if (empObj.LastName == string.Empty)
                {
                    empValidated = false;
                    message.Append("Employee Last Name should be Provided\n");
                }
                else if (!Regex.IsMatch(empObj.LastName, "[A-Z][a-z]+"))
                {
                    message.Append("Employee Last Name should have alphabets only and it should start with capital\n");
                    empValidated = false;
                }
                if (empObj.PhoneNo.ToString().Length == 0)
                {
                    message.Append("Phone Number should be Provided\n");
                    empValidated = false;
                }
                else if (!Regex.IsMatch(empObj.PhoneNo.ToString(),"[7-9][0-9]{9}"))
                {
                    message.Append("Phone Number should have 10 digits exactly and it should start with 7 or 8 or 9\n");
                    empValidated = false;
                }
                if (empObj.DOJ == null)
                {
                    message.Append("Date of Joining should be provided\n");
                    empValidated = false;
                }
                else if (empObj.DOJ > DateTime.Today)
                {
                    message.Append("Date of Joining should be less than or equal to current date\n");
                    empValidated = false;
                }
                if (empObj.DOB == null)
                {
                    message.Append("Date of Birth should be provided\n");
                    empValidated = false;
                }
                else if (empObj.DOB > DateTime.Today)
                {
                    message.Append("Date of Birth should be less than current date\n");
                    empValidated = false;
                }
                if (empObj.Address == string.Empty)
                {
                    empValidated = false;
                    message.Append("Address should be Provided\n");
                }
                if (empObj.MaritalStatus == string.Empty)
                {
                    empValidated = false;
                    message.Append("Marital status should be Provided\n");
                }
                else if (empObj.MaritalStatus.ToLower() != "married" && empObj.MaritalStatus.ToLower() != "unmarried")
                {
                    empValidated = false;
                    message.Append("Marital status should be either Married or Unmarried");
                }
                if (empObj.Salary == null)
                {
                    empValidated = false;
                    message.Append("Salary should be Provided\n");
                }
                if(empObj.Gender == string.Empty)
                {
                    empValidated = false;
                    message.Append("Gender should be Provided\n");
                }
                else if (empObj.Gender.ToLower() != "male"  && empObj.Gender.ToLower() != "female")
                {
                    message.Append("Gender should be either Male or Female \n");
                    empValidated = false;
                }
                if (empValidated == false)
                {
                    throw new EmployeeException(message.ToString());
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empValidated;
        }

        //Method to validate Department data
        public static bool ValidateDepartment(Department deptObj)
        {
            bool deptValidated = true;
            StringBuilder message1 = new StringBuilder();

            try
            {
                if (deptObj.DepartmentID.ToString().Length == 0)
                {
                    deptValidated = false;
                    message1.Append("Department ID Should be Provided");
                }
                else if (!Regex.IsMatch(deptObj.DepartmentID.ToString(), @"^[0-9]+$"))
                {
                    deptValidated = false;
                    message1.Append("Department ID Should contain only numbers");
                }
                if (deptObj.DepartmentName == string.Empty)
                {
                    deptValidated = false;
                    message1.Append("Department Name should be Provided\n");
                }
               
                else if (!Regex.IsMatch(deptObj.DepartmentName, @"^[a-zA-Z ]+$"))
                {
                    deptValidated = false;
                    message1.Append("Department Name should only contain characters");
                }
                if (deptValidated == false)
                {
                    throw new EmployeeException(message1.ToString());
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return deptValidated;
        }

        //Method to validate Designation data
        public static bool ValidateDesignation(Designation desgObj)
        {
            bool desgValidated = true;
            StringBuilder message2 = new StringBuilder();

            try
            {
                if (desgObj.DesignationID == string.Empty)
                {
                    desgValidated = false;
                    message2.Append("Designation ID should be Provided\n");
                }
                if (desgValidated == false)
                {
                    throw new EmployeeException(message2.ToString());
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return desgValidated;
        }

        //Method to validate Client data
        public static bool ValidateClient(Client clObj)
        {
            bool clientValidated = true;
            StringBuilder message3 = new StringBuilder();

            try
            {
                if (clObj.ClientID == string.Empty)
                {
                    clientValidated = false;
                    message3.Append("Client ID should be Provided\n");
                }

                else if (!Regex.IsMatch(clObj.ClientID, @"^[a-zA-Z][a-zA-Z0-9]*$"))
                {
                    clientValidated = false;
                    message3.Append("Client ID should contain alphanumeric value\n");
                }
                if (clObj.ClientName == string.Empty)
                {
                    clientValidated = false;
                    message3.Append("Client Name should be Provided\n");
                }

                else if (!Regex.IsMatch(clObj.ClientName, @"^[a-zA-Z ]+$"))
                {
                    clientValidated = false;
                    message3.Append("Client Name should only contain characters");
                }
                if (clientValidated == false)
                {
                    throw new EmployeeException(message3.ToString());
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return clientValidated;
        }

        //Method to validate Project data
        public static bool ValidateProject(Project projObj)
        {
            bool projValidated = true;
            StringBuilder message4 = new StringBuilder();

            try
            {
                if (projObj.ProjectID == string.Empty)
                {
                    projValidated = false;
                    message4.Append("Project ID should be Provided\n");
                }

                else if (!Regex.IsMatch(projObj.ProjectID, @"^[a-zA-Z][a-zA-Z0-9]*$"))
                {
                    projValidated = false;
                    message4.Append("Project ID should contain alphanumeric value\n");
                }
                if (projObj.ProjectName == string.Empty)
                {
                    projValidated = false;
                    message4.Append("Project Name should be Provided\n");
                }

                else if (!Regex.IsMatch(projObj.ProjectName, @"^[a-zA-Z ]+$"))
                {
                    projValidated = false;
                    message4.Append("Project Name should only contain characters");
                }
                if (projObj.ProjectDetails == string.Empty)
                {
                    projValidated = false;
                    message4.Append("Project Details should be provided\n");
                }
                else if (!Regex.IsMatch(projObj.ProjectDetails, @"^[a-zA-Z ]+$"))
                {
                    projValidated = false;
                    message4.Append("Project details should only contain characters");
                }
                if (projObj.ClientID == string.Empty)
                {
                    projValidated = false;
                    message4.Append("Client ID should be Provided\n");
                }

                else if (!Regex.IsMatch(projObj.ClientID, @"^[a-zA-Z][a-zA-Z0-9]*$"))
                {
                    projValidated = false;
                    message4.Append("Client ID should contain alphanumeric value\n");
                }
                if (projObj.ManagerID < 1000 || projObj.ManagerID > 9999)
                {
                    message4.Append("Employee ID should have 4 digits only\n");
                    projValidated = false;
                }
                if (projValidated == false)
                {
                    throw new EmployeeException(message4.ToString());
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return projValidated;
        }

        //Method to validate Shift detail data
        public static bool ValidateShiftDetail(ShiftDetail shftObj)
        {
            bool shftValidated = true;
            StringBuilder message5 = new StringBuilder();

            try
            {
                if (shftValidated == false)
                {
                    throw new EmployeeException(message5.ToString());
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return shftValidated;
        }

        //Method to validate Employee Project data
        public static bool ValidateEmpProject(EmployeeProject emprojObj)
        {
            bool emprojValidated = true;
            StringBuilder message6 = new StringBuilder();

            try
            {
                if (emprojValidated == false)
                {
                    throw new EmployeeException(message6.ToString());
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return emprojValidated;
        }

        //Method to validate Employee shift details data
        public static bool ValidateEmpShift(EmployeeShiftdetails empshftObj)
        {
            bool empshftValidated = true;
            StringBuilder message7 = new StringBuilder();

            try
            {
                if (empshftValidated == false)
                {
                    throw new EmployeeException(message7.ToString());
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return empshftValidated;
        }

        //Method to validate Grade Master data
        public static bool ValidateGradeMaster(GradeMaster gradeObj)
        {
            bool gradeValidated = true;
            StringBuilder message8 = new StringBuilder();

            try
            {
                if (gradeValidated == false)
                {
                    throw new EmployeeException(message8.ToString());
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return gradeValidated;
        }

    }
}
