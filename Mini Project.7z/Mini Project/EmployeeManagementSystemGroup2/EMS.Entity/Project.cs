﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    /// <summary>
    /// Author : 
    /// Modification Date :
    /// Change Description : 
    /// </summary>
    public class Project
    {
        #region Properties

            //Get or Set Project ID
            public string ProjectID { get; set; }

            //Get or Set Project Name
            public string ProjectName { get; set; }

            //Get or Set Description
            public string Description { get; set; }

            //Get or Set Client ID
            public string ClientID { get; set; }

            //Get or Set Manager ID
            public int ManagerID { get; set; }

        #endregion
    }
}
